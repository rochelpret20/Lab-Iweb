<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c"
           uri="http://java.sun.com/jsp/jstl/core" %>

<!DOCTYPE html>
<html>
<head>

    <meta charset="UTF-8">

    <title>Sedes</title>

    <link rel="stylesheet"
          href="${pageContext.request.contextPath}/css/estilos.css">

</head>
<body>

<%@ include file="includes/navbar.jspf" %>

<div class="contenedor">

    <h1>Listado de Sedes</h1>

    <div class="barra-superior">

        <a class="btn btn-nuevo"
           href="${pageContext.request.contextPath}/sedes?action=nuevo">

            Agregar Elemento

        </a>

    </div>

    <table>

        <thead>

        <tr>

            <th>ID</th>
            <th>Distrito</th>
            <th>Dirección</th>
            <th>Editar</th>
            <th>Eliminar</th>

        </tr>

        </thead>

        <tbody>

        <c:forEach var="s"
                   items="${listaSedes}">

            <tr>

                <td>${s.idSede}</td>
                <td>${s.distrito}</td>
                <td>${s.direccion}</td>

                <td>

                    <a class="btn btn-editar"
                       href="${pageContext.request.contextPath}/sedes?action=editar&id=${s.idSede}">

                        Editar

                    </a>

                </td>

                <td>

                    <a class="btn btn-eliminar"
                       href="${pageContext.request.contextPath}/sedes?action=eliminar&id=${s.idSede}"
                       onclick="return confirm('¿Eliminar sede?')">

                        Eliminar

                    </a>

                </td>

            </tr>

        </c:forEach>

        </tbody>

    </table>

</div>

</body>
</html>
