<%@ page contentType="text/html;charset=UTF-8" %>

<!DOCTYPE html>
<html>
<head>

    <meta charset="UTF-8">

    <title>Sede</title>

    <link rel="stylesheet"
          href="${pageContext.request.contextPath}/css/estilos.css">

</head>
<body>

<%@ include file="includes/navbar.jspf" %>

<div class="contenedor-form">

    <div class="card">

        <h2>

            ${empty sede ?
                    "Registrar Sede"
                    :
                    "Editar Sede"}

        </h2>

        <form method="post"
              action="${pageContext.request.contextPath}/sedes">

            <input type="hidden"
                   name="idSede"
                   value="${sede.idSede}">

            <label>Distrito</label>

            <input type="text"
                   name="distrito"
                   value="${sede.distrito}"
                   required>

            <label>Dirección</label>

            <input type="text"
                   name="direccion"
                   value="${sede.direccion}"
                   required>

            <div class="botones-form">

                <button type="submit">

                    Guardar

                </button>

                <a class="btn btn-regresar"
                   href="${pageContext.request.contextPath}/sedes">

                    Cancelar

                </a>

            </div>

        </form>

    </div>

</div>

</body>
</html>
