<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c"
           uri="http://java.sun.com/jsp/jstl/core" %>

<!DOCTYPE html>
<html>
<head>

    <meta charset="UTF-8">

    <title>Autos</title>

    <link rel="stylesheet"
          href="${pageContext.request.contextPath}/css/estilos.css">

</head>
<body>

<%@ include file="includes/navbar.jspf" %>

<div class="contenedor">

    <h1>Listado de Autos</h1>

    <div class="barra-superior">

        <a class="btn btn-nuevo"
           href="${pageContext.request.contextPath}/autos?action=nuevo">

            Agregar Elemento

        </a>

    </div>

    <table>

        <thead>

        <tr>

            <th>ID</th>
            <th>Modelo</th>
            <th>Color</th>
            <th>Kilometraje</th>
            <th>Sede</th>
            <th>Costo por día</th>
            <th>Editar</th>
            <th>Eliminar</th>

        </tr>

        </thead>

        <tbody>

        <c:forEach var="a"
                   items="${listaAutos}">

            <tr>

                <td>${a.idAuto}</td>
                <td>${a.modelo}</td>
                <td>${a.color}</td>
                <td>${a.kilometraje}</td>
                <td>${a.sedeNombre}</td>
                <td>S/ ${a.costoPorDia}</td>

                <td>

                    <a class="btn btn-editar"
                       href="${pageContext.request.contextPath}/autos?action=editar&id=${a.idAuto}">

                        Editar

                    </a>

                </td>

                <td>

                    <a class="btn btn-eliminar"
                       href="${pageContext.request.contextPath}/autos?action=eliminar&id=${a.idAuto}"
                       onclick="return confirm('¿Eliminar auto?')">

                        Eliminar

                    </a>

                </td>

            </tr>

        </c:forEach>

        </tbody>

    </table>

</div>

</body>
</html>
