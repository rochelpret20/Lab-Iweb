<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c"
           uri="http://java.sun.com/jsp/jstl/core" %>

<!DOCTYPE html>
<html>
<head>

    <meta charset="UTF-8">

    <title>Auto</title>

    <link rel="stylesheet"
          href="${pageContext.request.contextPath}/css/estilos.css">

</head>
<body>

<%@ include file="includes/navbar.jspf" %>

<div class="contenedor-form">

    <div class="card">

        <h2>

            ${empty auto ?
                    "Registrar Auto"
                    :
                    "Editar Auto"}

        </h2>

        <form method="post"
              action="${pageContext.request.contextPath}/autos">

            <input type="hidden"
                   name="idAuto"
                   value="${auto.idAuto}">

            <label>Modelo</label>

            <input type="text"
                   name="modelo"
                   value="${auto.modelo}"
                   required>

            <label>Color</label>

            <input type="text"
                   name="color"
                   value="${auto.color}"
                   required>

            <label>Kilometraje</label>

            <input type="number"
                   name="kilometraje"
                   value="${auto.kilometraje}"
                   required>

            <label>Sede</label>

            <select name="idSede">

                <c:forEach var="s"
                           items="${listaSedes}">

                    <option value="${s.idSede}"

                        ${auto.idSede ==
                                s.idSede ?
                                'selected' : ''}>

                            ${s.distrito}
                            -
                            ${s.direccion}

                    </option>

                </c:forEach>

            </select>

            <label>Costo por día</label>

            <input type="number"
                   step="0.01"
                   name="costoPorDia"
                   value="${auto.costoPorDia}"
                   required>

            <div class="botones-form">

                <button type="submit">

                    Guardar

                </button>

                <a class="btn btn-regresar"
                   href="${pageContext.request.contextPath}/autos">

                    Cancelar

                </a>

            </div>

        </form>

    </div>

</div>

</body>
</html>
