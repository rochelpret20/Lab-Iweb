<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c"
           uri="http://java.sun.com/jsp/jstl/core" %>

<!DOCTYPE html>
<html>
<head>

    <meta charset="UTF-8">

    <title>Seguros</title>

    <link rel="stylesheet"
          href="${pageContext.request.contextPath}/css/estilos.css">

</head>
<body>

<%@ include file="includes/navbar.jspf" %>

<div class="contenedor">

    <h1>Listado de Seguros</h1>

    <div class="barra-superior">

        <a class="btn btn-nuevo"
           href="${pageContext.request.contextPath}/seguros?action=nuevo">

            Agregar Elemento

        </a>

    </div>

    <table>

        <thead>

        <tr>

            <th>ID</th>
            <th>Empresa Aseguradora</th>
            <th>Cobertura Máxima</th>
            <th>Tarifa</th>
            <th>Editar</th>
            <th>Eliminar</th>

        </tr>

        </thead>

        <tbody>

        <c:forEach var="s"
                   items="${listaSeguros}">

            <tr>

                <td>${s.idSeguro}</td>
                <td>${s.empresaAseguradora}</td>
                <td>S/ ${s.coberturaMaxima}</td>
                <td>S/ ${s.tarifa}</td>

                <td>

                    <a class="btn btn-editar"
                       href="${pageContext.request.contextPath}/seguros?action=editar&id=${s.idSeguro}">

                        Editar

                    </a>

                </td>

                <td>

                    <a class="btn btn-eliminar"
                       href="${pageContext.request.contextPath}/seguros?action=eliminar&id=${s.idSeguro}"
                       onclick="return confirm('¿Eliminar seguro?')">

                        Eliminar

                    </a>

                </td>

            </tr>

        </c:forEach>

        </tbody>

    </table>

</div>

</body>
</html>
