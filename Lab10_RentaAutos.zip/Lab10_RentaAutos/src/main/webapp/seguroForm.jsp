<%@ page contentType="text/html;charset=UTF-8" %>

<!DOCTYPE html>
<html>
<head>

    <meta charset="UTF-8">

    <title>Seguro</title>

    <link rel="stylesheet"
          href="${pageContext.request.contextPath}/css/estilos.css">

</head>
<body>

<%@ include file="includes/navbar.jspf" %>

<div class="contenedor-form">

    <div class="card">

        <h2>

            ${empty seguro ?
                    "Registrar Seguro"
                    :
                    "Editar Seguro"}

        </h2>

        <form method="post"
              action="${pageContext.request.contextPath}/seguros">

            <input type="hidden"
                   name="idSeguro"
                   value="${seguro.idSeguro}">

            <label>Empresa Aseguradora</label>

            <input type="text"
                   name="empresaAseguradora"
                   value="${seguro.empresaAseguradora}"
                   required>

            <label>Cobertura Máxima</label>

            <input type="number"
                   step="0.01"
                   name="coberturaMaxima"
                   value="${seguro.coberturaMaxima}"
                   required>

            <label>Tarifa</label>

            <input type="number"
                   step="0.01"
                   name="tarifa"
                   value="${seguro.tarifa}"
                   required>

            <div class="botones-form">

                <button type="submit">

                    Guardar

                </button>

                <a class="btn btn-regresar"
                   href="${pageContext.request.contextPath}/seguros">

                    Cancelar

                </a>

            </div>

        </form>

    </div>

</div>

</body>
</html>
