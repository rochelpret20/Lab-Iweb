package com.lab.beans;

public class Seguro {

    private int idSeguro;

    private String empresaAseguradora;

    private double coberturaMaxima;

    private double tarifa;

    public int getIdSeguro() {
        return idSeguro;
    }

    public void setIdSeguro(int idSeguro) {
        this.idSeguro = idSeguro;
    }

    public String getEmpresaAseguradora() {
        return empresaAseguradora;
    }

    public void setEmpresaAseguradora(String empresaAseguradora) {
        this.empresaAseguradora = empresaAseguradora;
    }

    public double getCoberturaMaxima() {
        return coberturaMaxima;
    }

    public void setCoberturaMaxima(double coberturaMaxima) {
        this.coberturaMaxima = coberturaMaxima;
    }

    public double getTarifa() {
        return tarifa;
    }

    public void setTarifa(double tarifa) {
        this.tarifa = tarifa;
    }
}
