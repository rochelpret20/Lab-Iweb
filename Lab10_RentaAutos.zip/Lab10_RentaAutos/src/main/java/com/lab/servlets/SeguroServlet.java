package com.lab.servlets;

import com.lab.beans.Seguro;
import com.lab.dao.DaoSeguro;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/seguros")
public class SeguroServlet
        extends HttpServlet {

    private final DaoSeguro daoSeguro =
            new DaoSeguro();

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException,
            IOException {

        HttpSession session =
                request.getSession(false);

        if(session == null ||
                session.getAttribute("usuario")
                        == null){

            response.sendRedirect(
                    request.getContextPath()
                            + "/login");

            return;
        }

        String action =
                request.getParameter("action");

        if(action == null){

            request.setAttribute(
                    "listaSeguros",
                    daoSeguro.listarSeguros());

            request.getRequestDispatcher(
                            "/seguros.jsp")
                    .forward(
                            request,
                            response);

            return;
        }

        switch(action){

            case "nuevo":

                request.getRequestDispatcher(
                                "/seguroForm.jsp")
                        .forward(
                                request,
                                response);

                break;

            case "editar":

                int idEditar =
                        Integer.parseInt(
                                request.getParameter(
                                        "id"));

                request.setAttribute(
                        "seguro",
                        daoSeguro.obtenerSeguro(
                                idEditar));

                request.getRequestDispatcher(
                                "/seguroForm.jsp")
                        .forward(
                                request,
                                response);

                break;

            case "eliminar":

                int idEliminar =
                        Integer.parseInt(
                                request.getParameter(
                                        "id"));

                daoSeguro.eliminarSeguro(
                        idEliminar);

                response.sendRedirect(
                        request.getContextPath()
                                + "/seguros");

                break;

            default:

                response.sendRedirect(
                        request.getContextPath()
                                + "/seguros");
        }
    }

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws IOException {

        HttpSession session =
                request.getSession(false);

        if(session == null ||
                session.getAttribute("usuario")
                        == null){

            response.sendRedirect(
                    request.getContextPath()
                            + "/login");

            return;
        }

        String idSeguro =
                request.getParameter(
                        "idSeguro");

        Seguro seguro =
                new Seguro();

        seguro.setEmpresaAseguradora(
                request.getParameter(
                        "empresaAseguradora"));

        seguro.setCoberturaMaxima(
                Double.parseDouble(
                        request.getParameter(
                                "coberturaMaxima")));

        seguro.setTarifa(
                Double.parseDouble(
                        request.getParameter(
                                "tarifa")));

        if(idSeguro == null ||
                idSeguro.isEmpty()){

            daoSeguro.crearSeguro(
                    seguro);

        }else{

            seguro.setIdSeguro(
                    Integer.parseInt(
                            idSeguro));

            daoSeguro.actualizarSeguro(
                    seguro);
        }

        response.sendRedirect(
                request.getContextPath()
                        + "/seguros");
    }
}
