package com.lab.servlets;

import com.lab.beans.Sede;
import com.lab.dao.DaoSede;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/sedes")
public class SedeServlet
        extends HttpServlet {

    private final DaoSede daoSede =
            new DaoSede();

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException,
            IOException {

        HttpSession session =
                request.getSession(false);

        if(session == null ||
                session.getAttribute("usuario")
                        == null){

            response.sendRedirect(
                    request.getContextPath()
                            + "/login");

            return;
        }

        String action =
                request.getParameter("action");

        if(action == null){

            request.setAttribute(
                    "listaSedes",
                    daoSede.listarSedes());

            request.getRequestDispatcher(
                            "/sedes.jsp")
                    .forward(
                            request,
                            response);

            return;
        }

        switch(action){

            case "nuevo":

                request.getRequestDispatcher(
                                "/sedeForm.jsp")
                        .forward(
                                request,
                                response);

                break;

            case "editar":

                int idEditar =
                        Integer.parseInt(
                                request.getParameter(
                                        "id"));

                request.setAttribute(
                        "sede",
                        daoSede.obtenerSede(
                                idEditar));

                request.getRequestDispatcher(
                                "/sedeForm.jsp")
                        .forward(
                                request,
                                response);

                break;

            case "eliminar":

                int idEliminar =
                        Integer.parseInt(
                                request.getParameter(
                                        "id"));

                daoSede.eliminarSede(
                        idEliminar);

                response.sendRedirect(
                        request.getContextPath()
                                + "/sedes");

                break;

            default:

                response.sendRedirect(
                        request.getContextPath()
                                + "/sedes");
        }
    }

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws IOException {

        HttpSession session =
                request.getSession(false);

        if(session == null ||
                session.getAttribute("usuario")
                        == null){

            response.sendRedirect(
                    request.getContextPath()
                            + "/login");

            return;
        }

        String idSede =
                request.getParameter(
                        "idSede");

        Sede sede =
                new Sede();

        sede.setDistrito(
                request.getParameter(
                        "distrito"));

        sede.setDireccion(
                request.getParameter(
                        "direccion"));

        if(idSede == null ||
                idSede.isEmpty()){

            daoSede.crearSede(
                    sede);

        }else{

            sede.setIdSede(
                    Integer.parseInt(
                            idSede));

            daoSede.actualizarSede(
                    sede);
        }

        response.sendRedirect(
                request.getContextPath()
                        + "/sedes");
    }
}
