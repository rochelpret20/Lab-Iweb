package com.lab.servlets;

import com.lab.beans.Auto;
import com.lab.dao.DaoAuto;
import com.lab.dao.DaoSede;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/autos")
public class AutoServlet
        extends HttpServlet {

    private final DaoAuto daoAuto =
            new DaoAuto();

    private final DaoSede daoSede =
            new DaoSede();

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException,
            IOException {

        HttpSession session =
                request.getSession(false);

        if(session == null ||
                session.getAttribute("usuario")
                        == null){

            response.sendRedirect(
                    request.getContextPath()
                            + "/login");

            return;
        }

        String action =
                request.getParameter("action");

        if(action == null){

            request.setAttribute(
                    "listaAutos",
                    daoAuto.listarAutos());

            request.getRequestDispatcher(
                            "/autos.jsp")
                    .forward(
                            request,
                            response);

            return;
        }

        switch(action){

            case "nuevo":

                request.setAttribute(
                        "listaSedes",
                        daoSede.listarSedes());

                request.getRequestDispatcher(
                                "/autoForm.jsp")
                        .forward(
                                request,
                                response);

                break;

            case "editar":

                int idEditar =
                        Integer.parseInt(
                                request.getParameter(
                                        "id"));

                request.setAttribute(
                        "auto",
                        daoAuto.obtenerAuto(
                                idEditar));

                request.setAttribute(
                        "listaSedes",
                        daoSede.listarSedes());

                request.getRequestDispatcher(
                                "/autoForm.jsp")
                        .forward(
                                request,
                                response);

                break;

            case "eliminar":

                int idEliminar =
                        Integer.parseInt(
                                request.getParameter(
                                        "id"));

                daoAuto.eliminarAuto(
                        idEliminar);

                response.sendRedirect(
                        request.getContextPath()
                                + "/autos");

                break;

            default:

                response.sendRedirect(
                        request.getContextPath()
                                + "/autos");
        }
    }

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws IOException {

        HttpSession session =
                request.getSession(false);

        if(session == null ||
                session.getAttribute("usuario")
                        == null){

            response.sendRedirect(
                    request.getContextPath()
                            + "/login");

            return;
        }

        String idAuto =
                request.getParameter(
                        "idAuto");

        Auto auto =
                new Auto();

        auto.setModelo(
                request.getParameter(
                        "modelo"));

        auto.setColor(
                request.getParameter(
                        "color"));

        auto.setKilometraje(
                Integer.parseInt(
                        request.getParameter(
                                "kilometraje")));

        auto.setIdSede(
                Integer.parseInt(
                        request.getParameter(
                                "idSede")));

        auto.setCostoPorDia(
                Double.parseDouble(
                        request.getParameter(
                                "costoPorDia")));

        if(idAuto == null ||
                idAuto.isEmpty()){

            daoAuto.crearAuto(
                    auto);

        }else{

            auto.setIdAuto(
                    Integer.parseInt(
                            idAuto));

            daoAuto.actualizarAuto(
                    auto);
        }

        response.sendRedirect(
                request.getContextPath()
                        + "/autos");
    }
}
