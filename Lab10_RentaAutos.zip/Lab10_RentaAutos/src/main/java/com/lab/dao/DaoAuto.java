package com.lab.dao;

import com.lab.beans.Auto;
import com.lab.config.ConexionDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class DaoAuto {

    public ArrayList<Auto> listarAutos() {

        ArrayList<Auto> lista =
                new ArrayList<>();

        String sql = """
                SELECT
                a.idauto,
                a.modelo,
                a.color,
                a.kilometraje,
                a.sede_idsede,
                a.costo_por_dia,
                s.distrito

                FROM auto a

                INNER JOIN sede s
                ON a.sede_idsede =
                   s.idsede

                ORDER BY a.idauto
                """;

        try(Connection con =
                    ConexionDB.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ResultSet rs =
                    ps.executeQuery()) {

            while(rs.next()) {

                Auto auto =
                        new Auto();

                auto.setIdAuto(
                        rs.getInt(
                                "idauto"));

                auto.setModelo(
                        rs.getString(
                                "modelo"));

                auto.setColor(
                        rs.getString(
                                "color"));

                auto.setKilometraje(
                        rs.getInt(
                                "kilometraje"));

                auto.setIdSede(
                        rs.getInt(
                                "sede_idsede"));

                auto.setCostoPorDia(
                        rs.getDouble(
                                "costo_por_dia"));

                auto.setSedeNombre(
                        rs.getString(
                                "distrito"));

                lista.add(auto);
            }

        } catch(Exception e) {

            e.printStackTrace();
        }

        return lista;
    }

    public Auto obtenerAuto(
            int idAuto) {

        Auto auto = null;

        String sql = """
                SELECT *
                FROM auto
                WHERE idauto = ?
                """;

        try(Connection con =
                    ConexionDB.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(sql)) {

            ps.setInt(
                    1,
                    idAuto);

            ResultSet rs =
                    ps.executeQuery();

            if(rs.next()) {

                auto = new Auto();

                auto.setIdAuto(
                        rs.getInt(
                                "idauto"));

                auto.setModelo(
                        rs.getString(
                                "modelo"));

                auto.setColor(
                        rs.getString(
                                "color"));

                auto.setKilometraje(
                        rs.getInt(
                                "kilometraje"));

                auto.setIdSede(
                        rs.getInt(
                                "sede_idsede"));

                auto.setCostoPorDia(
                        rs.getDouble(
                                "costo_por_dia"));
            }

        } catch(Exception e) {

            e.printStackTrace();
        }

        return auto;
    }

    public void crearAuto(
            Auto auto) {

        String sql = """
                INSERT INTO auto
                (
                    modelo,
                    color,
                    kilometraje,
                    sede_idsede,
                    costo_por_dia
                )
                VALUES
                (
                    ?, ?, ?, ?, ?
                )
                """;

        try(Connection con =
                    ConexionDB.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(sql)) {

            ps.setString(
                    1,
                    auto.getModelo());

            ps.setString(
                    2,
                    auto.getColor());

            ps.setInt(
                    3,
                    auto.getKilometraje());

            ps.setInt(
                    4,
                    auto.getIdSede());

            ps.setDouble(
                    5,
                    auto.getCostoPorDia());

            ps.executeUpdate();

        } catch(Exception e) {

            e.printStackTrace();
        }
    }

    public void actualizarAuto(
            Auto auto) {

        String sql = """
                UPDATE auto
                SET
                modelo = ?,
                color = ?,
                kilometraje = ?,
                sede_idsede = ?,
                costo_por_dia = ?
                WHERE idauto = ?
                """;

        try(Connection con =
                    ConexionDB.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(sql)) {

            ps.setString(
                    1,
                    auto.getModelo());

            ps.setString(
                    2,
                    auto.getColor());

            ps.setInt(
                    3,
                    auto.getKilometraje());

            ps.setInt(
                    4,
                    auto.getIdSede());

            ps.setDouble(
                    5,
                    auto.getCostoPorDia());

            ps.setInt(
                    6,
                    auto.getIdAuto());

            ps.executeUpdate();

        } catch(Exception e) {

            e.printStackTrace();
        }
    }

    public void eliminarAuto(
            int idAuto) {

        String sql = """
                DELETE FROM auto
                WHERE idauto = ?
                """;

        try(Connection con =
                    ConexionDB.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(sql)) {

            ps.setInt(
                    1,
                    idAuto);

            ps.executeUpdate();

        } catch(Exception e) {

            e.printStackTrace();
        }
    }
}
