package com.lab.dao;

import com.lab.beans.Sede;
import com.lab.config.ConexionDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class DaoSede {

    public ArrayList<Sede> listarSedes() {

        ArrayList<Sede> lista =
                new ArrayList<>();

        String sql = """
                SELECT *
                FROM sede
                ORDER BY idsede
                """;

        try(Connection con =
                    ConexionDB.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ResultSet rs =
                    ps.executeQuery()) {

            while(rs.next()) {

                Sede sede =
                        new Sede();

                sede.setIdSede(
                        rs.getInt(
                                "idsede"));

                sede.setDistrito(
                        rs.getString(
                                "distrito"));

                sede.setDireccion(
                        rs.getString(
                                "direccion"));

                lista.add(sede);
            }

        } catch(Exception e) {

            e.printStackTrace();
        }

        return lista;
    }

    public Sede obtenerSede(
            int idSede) {

        Sede sede = null;

        String sql = """
                SELECT *
                FROM sede
                WHERE idsede = ?
                """;

        try(Connection con =
                    ConexionDB.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(sql)) {

            ps.setInt(
                    1,
                    idSede);

            ResultSet rs =
                    ps.executeQuery();

            if(rs.next()) {

                sede = new Sede();

                sede.setIdSede(
                        rs.getInt(
                                "idsede"));

                sede.setDistrito(
                        rs.getString(
                                "distrito"));

                sede.setDireccion(
                        rs.getString(
                                "direccion"));
            }

        } catch(Exception e) {

            e.printStackTrace();
        }

        return sede;
    }

    public void crearSede(
            Sede sede) {

        String sql = """
                INSERT INTO sede
                (
                    distrito,
                    direccion
                )
                VALUES
                (
                    ?, ?
                )
                """;

        try(Connection con =
                    ConexionDB.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(sql)) {

            ps.setString(
                    1,
                    sede.getDistrito());

            ps.setString(
                    2,
                    sede.getDireccion());

            ps.executeUpdate();

        } catch(Exception e) {

            e.printStackTrace();
        }
    }

    public void actualizarSede(
            Sede sede) {

        String sql = """
                UPDATE sede
                SET
                distrito = ?,
                direccion = ?
                WHERE idsede = ?
                """;

        try(Connection con =
                    ConexionDB.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(sql)) {

            ps.setString(
                    1,
                    sede.getDistrito());

            ps.setString(
                    2,
                    sede.getDireccion());

            ps.setInt(
                    3,
                    sede.getIdSede());

            ps.executeUpdate();

        } catch(Exception e) {

            e.printStackTrace();
        }
    }

    public void eliminarSede(
            int idSede) {

        String sql = """
                DELETE FROM sede
                WHERE idsede = ?
                """;

        try(Connection con =
                    ConexionDB.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(sql)) {

            ps.setInt(
                    1,
                    idSede);

            ps.executeUpdate();

        } catch(Exception e) {

            e.printStackTrace();
        }
    }
}
