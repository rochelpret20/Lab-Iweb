package com.lab.dao;

import com.lab.beans.Usuario;
import com.lab.config.ConexionDB;

import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DaoUsuario {

    public Usuario validarUsuario(
            String correo,
            String password) {

        Usuario usuario = null;

        String sql = """
                SELECT
                u.idusuario,
                u.nombres,
                u.apellidos,
                u.telefono,
                cu.correo,
                cu.contraseña_encriptada

                FROM credenciales_usuario cu

                INNER JOIN usuario u
                ON cu.idusuario =
                   u.idusuario

                WHERE cu.correo = ?
                """;

        try (Connection con =
                     ConexionDB.getConnection();

             PreparedStatement ps =
                     con.prepareStatement(sql)) {

            ps.setString(
                    1,
                    correo);

            ResultSet rs =
                    ps.executeQuery();

            if (rs.next()) {

                String hashBD =
                        rs.getString(
                                "contraseña_encriptada");

                String hashIngresado =
                        generarSHA256(
                                password);

                if (hashBD.equals(
                        hashIngresado)) {

                    usuario =
                            new Usuario();

                    usuario.setIdUsuario(
                            rs.getInt(
                                    "idusuario"));

                    usuario.setNombres(
                            rs.getString(
                                    "nombres"));

                    usuario.setApellidos(
                            rs.getString(
                                    "apellidos"));

                    usuario.setTelefono(
                            rs.getInt(
                                    "telefono"));

                    usuario.setCorreo(
                            rs.getString(
                                    "correo"));
                }
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return usuario;
    }

    public String generarSHA256(
            String texto) {

        try {

            MessageDigest md =
                    MessageDigest.getInstance(
                            "SHA-256");

            byte[] hash =
                    md.digest(
                            texto.getBytes());

            StringBuilder sb =
                    new StringBuilder();

            for (byte b : hash) {

                sb.append(
                        String.format(
                                "%02x",
                                b));
            }

            return sb.toString();

        } catch (Exception e) {

            throw new RuntimeException(e);
        }
    }
}
