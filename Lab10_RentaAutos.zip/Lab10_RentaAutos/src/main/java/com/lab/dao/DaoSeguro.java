package com.lab.dao;

import com.lab.beans.Seguro;
import com.lab.config.ConexionDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class DaoSeguro {

    public ArrayList<Seguro> listarSeguros() {

        ArrayList<Seguro> lista =
                new ArrayList<>();

        String sql = """
                SELECT *
                FROM seguro
                ORDER BY idseguro
                """;

        try(Connection con =
                    ConexionDB.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ResultSet rs =
                    ps.executeQuery()) {

            while(rs.next()) {

                Seguro seguro =
                        new Seguro();

                seguro.setIdSeguro(
                        rs.getInt(
                                "idseguro"));

                seguro.setEmpresaAseguradora(
                        rs.getString(
                                "empresa_aseguradora"));

                seguro.setCoberturaMaxima(
                        rs.getDouble(
                                "cobertura_maxima"));

                seguro.setTarifa(
                        rs.getDouble(
                                "tarifa"));

                lista.add(seguro);
            }

        } catch(Exception e) {

            e.printStackTrace();
        }

        return lista;
    }

    public Seguro obtenerSeguro(
            int idSeguro) {

        Seguro seguro = null;

        String sql = """
                SELECT *
                FROM seguro
                WHERE idseguro = ?
                """;

        try(Connection con =
                    ConexionDB.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(sql)) {

            ps.setInt(
                    1,
                    idSeguro);

            ResultSet rs =
                    ps.executeQuery();

            if(rs.next()) {

                seguro = new Seguro();

                seguro.setIdSeguro(
                        rs.getInt(
                                "idseguro"));

                seguro.setEmpresaAseguradora(
                        rs.getString(
                                "empresa_aseguradora"));

                seguro.setCoberturaMaxima(
                        rs.getDouble(
                                "cobertura_maxima"));

                seguro.setTarifa(
                        rs.getDouble(
                                "tarifa"));
            }

        } catch(Exception e) {

            e.printStackTrace();
        }

        return seguro;
    }

    public void crearSeguro(
            Seguro seguro) {

        String sql = """
                INSERT INTO seguro
                (
                    empresa_aseguradora,
                    cobertura_maxima,
                    tarifa
                )
                VALUES
                (
                    ?, ?, ?
                )
                """;

        try(Connection con =
                    ConexionDB.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(sql)) {

            ps.setString(
                    1,
                    seguro.getEmpresaAseguradora());

            ps.setDouble(
                    2,
                    seguro.getCoberturaMaxima());

            ps.setDouble(
                    3,
                    seguro.getTarifa());

            ps.executeUpdate();

        } catch(Exception e) {

            e.printStackTrace();
        }
    }

    public void actualizarSeguro(
            Seguro seguro) {

        String sql = """
                UPDATE seguro
                SET
                empresa_aseguradora = ?,
                cobertura_maxima = ?,
                tarifa = ?
                WHERE idseguro = ?
                """;

        try(Connection con =
                    ConexionDB.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(sql)) {

            ps.setString(
                    1,
                    seguro.getEmpresaAseguradora());

            ps.setDouble(
                    2,
                    seguro.getCoberturaMaxima());

            ps.setDouble(
                    3,
                    seguro.getTarifa());

            ps.setInt(
                    4,
                    seguro.getIdSeguro());

            ps.executeUpdate();

        } catch(Exception e) {

            e.printStackTrace();
        }
    }

    public void eliminarSeguro(
            int idSeguro) {

        String sql = """
                DELETE FROM seguro
                WHERE idseguro = ?
                """;

        try(Connection con =
                    ConexionDB.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(sql)) {

            ps.setInt(
                    1,
                    idSeguro);

            ps.executeUpdate();

        } catch(Exception e) {

            e.printStackTrace();
        }
    }
}
