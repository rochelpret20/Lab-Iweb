# Laboratorio 2 - TEL137 GTICS - Renta de Autos

## 1. Configuración previa

1. Importar el proyecto en IntelliJ IDEA como proyecto Maven (`pom.xml` en la raíz).
2. Crear la base de datos ejecutando el script `database.sql` en MySQL Workbench
   o en la línea de comandos:
   ```
   mysql -u root -p < database.sql
   ```
3. Ajustar usuario/contraseña de la base de datos en
   `src/main/java/com/lab/config/ConexionDB.java` si es necesario
   (por defecto: usuario `root`, password `Rosell2025`).
4. Configurar un servidor Tomcat 10+ (Jakarta EE) en IntelliJ y desplegar
   el artefacto `war exploded`.
5. Usuario de prueba para iniciar sesión:
   - Correo: `juan@correo.com`
   - Contraseña: `123456`

## 2. Flujo de ramas Git (según enunciado)

```bash
git init
git add .
git commit -m "Proyecto base Lab2 - Renta de Autos"

# Rama principal y de desarrollo
git branch main
git checkout -b develop

# Pregunta 1: listados (autos, seguros, sedes)
git checkout -b flowList develop
git add .
git commit -m "Pregunta 1: vistas de listado con botones agregar/editar/eliminar"

# Pregunta 2: lógica de formularios (registrar auto y seguro)
git checkout -b flowData flowList
git add .
git commit -m "Pregunta 2: logica de registro de autos y seguros"

# Pregunta 3: lógica de eliminación
git checkout -b flowLogic flowData
git add .
git commit -m "Pregunta 3: logica de eliminacion de autos y seguros"

# Pregunta 3 (2 puntos): mergear flowLogic en develop
git checkout develop
git merge flowLogic

# Subir todo al remoto
git remote add origin <URL_DEL_REPOSITORIO>
git push -u origin main
git push -u origin develop
git push -u origin flowList
git push -u origin flowData
git push -u origin flowLogic
```

## 3. Resumen de la solución entregada

- **Pregunta 1**: vistas `autos.jsp`, `seguros.jsp`, `sedes.jsp` con botón
  "Agregar Elemento", una columna por cada campo de la tabla, y dos columnas
  con botones de Editar / Eliminar.
- **Pregunta 2**: `autoForm.jsp` y `seguroForm.jsp` con la lógica de captura
  e inserción manejada por `AutoServlet` y `SeguroServlet` (también se generó
  `SedeServlet` y `sedeForm.jsp` para completar el flujo de las 3 vistas).
- **Pregunta 3**: lógica de eliminación (`action=eliminar`) implementada en
  `AutoServlet` y `SeguroServlet`, invocada desde el botón "Eliminar" del
  listado.
- Autenticación simple con `LoginServlet` / `LogoutServlet`, usando las
  tablas `usuario` y `credenciales_usuario` del diagrama (contraseña
  almacenada como hash SHA-256).
