-- =========================================================
-- Script de creación de base de datos: lab10_rentaautos
-- Basado en el diagrama ER del Laboratorio 2 - TEL137 GTICS
-- =========================================================

CREATE DATABASE IF NOT EXISTS lab10_rentaautos
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE lab10_rentaautos;

-- ---------------------------------------------------------
-- Tabla: sede
-- ---------------------------------------------------------
CREATE TABLE sede (
    idsede      INT AUTO_INCREMENT PRIMARY KEY,
    distrito    VARCHAR(45)  NOT NULL,
    direccion   VARCHAR(200) NOT NULL
);

-- ---------------------------------------------------------
-- Tabla: seguro
-- ---------------------------------------------------------
CREATE TABLE seguro (
    idseguro              INT AUTO_INCREMENT PRIMARY KEY,
    empresa_aseguradora   VARCHAR(45) NOT NULL,
    cobertura_maxima      DOUBLE      NOT NULL,
    tarifa                DOUBLE      NOT NULL
);

-- ---------------------------------------------------------
-- Tabla: auto
-- ---------------------------------------------------------
CREATE TABLE auto (
    idauto         INT AUTO_INCREMENT PRIMARY KEY,
    modelo         VARCHAR(45) NOT NULL,
    color          VARCHAR(45) NOT NULL,
    kilometraje    INT         NOT NULL,
    sede_idsede    INT         NOT NULL,
    costo_por_dia  DOUBLE      NOT NULL,
    CONSTRAINT fk_auto_sede
        FOREIGN KEY (sede_idsede)
        REFERENCES sede (idsede)
);

-- ---------------------------------------------------------
-- Tabla: usuario
-- ---------------------------------------------------------
CREATE TABLE usuario (
    idusuario   INT AUTO_INCREMENT PRIMARY KEY,
    nombres     VARCHAR(100) NOT NULL,
    apellidos   VARCHAR(80)  NOT NULL,
    telefono    INT          NOT NULL
);

-- ---------------------------------------------------------
-- Tabla: credenciales_usuario
-- ---------------------------------------------------------
CREATE TABLE credenciales_usuario (
    idusuario              INT PRIMARY KEY,
    correo                 VARCHAR(45) NOT NULL UNIQUE,
    contraseña_encriptada  VARCHAR(64) NOT NULL,
    CONSTRAINT fk_credenciales_usuario
        FOREIGN KEY (idusuario)
        REFERENCES usuario (idusuario)
);

-- ---------------------------------------------------------
-- Tabla: renta_auto
-- ---------------------------------------------------------
CREATE TABLE renta_auto (
    id_renta            INT AUTO_INCREMENT PRIMARY KEY,
    auto_idauto         INT     NOT NULL,
    usuario_idusuario   INT     NOT NULL,
    seguro_idseguro     INT     NOT NULL,
    fecha_inicio        DATE    NOT NULL,
    fecha_fin           DATE    NOT NULL,
    cancelada           TINYINT NOT NULL DEFAULT 0,
    CONSTRAINT fk_renta_auto
        FOREIGN KEY (auto_idauto)
        REFERENCES auto (idauto),
    CONSTRAINT fk_renta_usuario
        FOREIGN KEY (usuario_idusuario)
        REFERENCES usuario (idusuario),
    CONSTRAINT fk_renta_seguro
        FOREIGN KEY (seguro_idseguro)
        REFERENCES seguro (idseguro)
);

-- ---------------------------------------------------------
-- Datos de prueba
-- ---------------------------------------------------------

INSERT INTO sede (distrito, direccion) VALUES
('San Isidro', 'Av. Javier Prado 123'),
('Miraflores', 'Av. Larco 456');

INSERT INTO seguro (empresa_aseguradora, cobertura_maxima, tarifa) VALUES
('Rimac Seguros', 50000.00, 35.50),
('Pacifico Seguros', 40000.00, 28.00);

INSERT INTO auto (modelo, color, kilometraje, sede_idsede, costo_por_dia) VALUES
('Toyota Yaris', 'Blanco', 15000, 1, 80.00),
('Hyundai Accent', 'Gris', 22000, 2, 75.00);

INSERT INTO usuario (nombres, apellidos, telefono) VALUES
('Juan', 'Pérez Gómez', 987654321);

-- Contraseña de prueba: 123456
-- Hash SHA-256: 8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92
INSERT INTO credenciales_usuario (idusuario, correo, contraseña_encriptada) VALUES
(1, 'juan@correo.com', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92');
